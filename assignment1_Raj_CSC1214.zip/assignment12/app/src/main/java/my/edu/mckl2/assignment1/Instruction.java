package my.edu.mckl2.assignment1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.util.Log;

public class Instruction extends AppCompatActivity {

    // Button to start quiz
    Button btnStartQuiz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instruction);

        btnStartQuiz = findViewById(R.id.btnStartQuiz);

        // Click listener for starting quiz
        btnStartQuiz.setOnClickListener(v -> {
            String userName = getIntent().getStringExtra("userName");
            String userAge = getIntent().getStringExtra("userAge");

            Log.d("InstructionActivity", "Start Quiz pressed for user: " + userName + ", Age: " + userAge);

            // Navigate to Question activity, passing name and age
            Intent intent = new Intent(Instruction.this, Question.class);
            intent.putExtra("userName", userName);
            intent.putExtra("userAge", userAge);
            startActivity(intent);
        });
    }
}
