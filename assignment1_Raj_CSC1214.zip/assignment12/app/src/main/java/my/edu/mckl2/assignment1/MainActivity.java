package my.edu.mckl2.assignment1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    // UI references
    EditText etName, etAge;
    Button btnContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        btnContinue = findViewById(R.id.btnContinue);

        // Button click listener for "Continue"
        btnContinue.setOnClickListener(v -> {
            String name = etName.getText().toString().trim(); // Get user name
            String age = etAge.getText().toString().trim();   // Get user age

            Log.d("MainActivity", "Continue pressed: Name=" + name + ", Age=" + age);

            // Validation: make sure both fields are filled
            if (name.isEmpty() || age.isEmpty()) {
                Toast.makeText(this, "Please enter both name and age", Toast.LENGTH_SHORT).show();
                Log.d("MainActivity", "User did not enter name or age");
                return;
            }

            // Generate unique key for this user
            String userKey = name.toLowerCase() + "_" + age;

            // Load saved preferences
            SharedPreferences prefs = getSharedPreferences("PersonalityApp", MODE_PRIVATE);
            String savedPersonality = prefs.getString(userKey, null);

            // Check if user already took the test
            if (savedPersonality != null) {
                Log.d("MainActivity", "Existing user detected: " + userKey);

                // Show dialog for existing user
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Welcome back!")
                        .setMessage("Hi " + name + ", you have taken the test previously. Your personality: " + savedPersonality + " \uD83C\uDF1F")
                        .setPositiveButton("Retake", (dialog, which) -> {
                            Log.d("MainActivity", "User chose to retake the quiz: " + userKey);

                            // Go directly to Question activity
                            Intent intent = new Intent(MainActivity.this, Question.class);
                            intent.putExtra("userName", name);
                            intent.putExtra("userAge", age);
                            startActivity(intent);
                        })
                        .setNegativeButton("OK", (dialog, which) -> {
                            Log.d("MainActivity", "User dismissed the dialog: " + userKey);
                            dialog.dismiss();
                        })
                        .setCancelable(false)
                        .show();
            } else {
                // New user → must go through Agreement first
                Log.d("MainActivity", "New user detected: " + userKey);

                Intent intent = new Intent(MainActivity.this, AgreementActivity.class);
                intent.putExtra("userName", name);
                intent.putExtra("userAge", age);
                startActivity(intent);
            }
        });
    }
}
