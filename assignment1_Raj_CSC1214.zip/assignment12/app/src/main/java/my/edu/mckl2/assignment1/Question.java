package my.edu.mckl2.assignment1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.content.Intent;
import android.view.Gravity;
import android.util.Log;
import android.widget.LinearLayout;

public class Question extends AppCompatActivity {

    // UI references
    private TextView questionText;
    private RadioGroup optionsGroup;
    private Button nextButton, prevButton;

    // Tracking current question and answers
    private int currentQuestion = 0;
    private int[] answers = new int[10];

    // Questions array
    private final String[] questions = new String[]{
            "I enjoy meeting new people and socializing.",
            "I prefer planning ahead rather than being spontaneous.",
            "I feel comfortable taking risks.",
            "I often reflect on my thoughts and feelings.",
            "I enjoy helping others even when it’s inconvenient.",
            "I get stressed easily in unexpected situations.",
            "I am motivated to achieve my goals even when challenges arise.",
            "I enjoy creative activities like drawing, writing, or designing.",
            "I usually rely on facts and logic rather than intuition when making decisions.",
            "I find it easy to adapt to new environments or situations."
    };

    private String userName, userAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        // Initialize UI
        questionText = findViewById(R.id.questionText);
        optionsGroup = findViewById(R.id.optionsGroup);
        nextButton = findViewById(R.id.nextButton);
        prevButton = findViewById(R.id.prevButton);

        // Get user data from Intent
        userName = getIntent().getStringExtra("userName");
        userAge = getIntent().getStringExtra("userAge");

        Log.d("QuestionActivity", "Quiz started for user: " + userName + ", Age: " + userAge);

        // Load first question
        loadQuestion();

        // Next button listener
        nextButton.setOnClickListener(v -> {
            int selectedId = optionsGroup.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton rb = findViewById(selectedId);
                answers[currentQuestion] = Integer.parseInt(rb.getText().toString());
                Log.d("QuestionActivity", "Answer recorded for question " + (currentQuestion + 1) + ": " + rb.getText());

                currentQuestion++;
                if (currentQuestion < questions.length) {
                    loadQuestion();
                } else {
                    showResults();
                }
            } else {
                Toast.makeText(this, "Please select an option", Toast.LENGTH_SHORT).show();
                Log.d("QuestionActivity", "User tried to proceed without selecting an option");
            }
        });

        // Previous button listener
        prevButton.setOnClickListener(v -> {
            if (currentQuestion > 0) {
                currentQuestion--;
                loadQuestion();
                Log.d("QuestionActivity", "Moved back to question " + (currentQuestion + 1));
            }
        });
    }

    // Load question and adjust buttons
    private void loadQuestion() {
        questionText.setText(questions[currentQuestion]);
        optionsGroup.clearCheck();

        nextButton.setText(currentQuestion == questions.length - 1 ? "Submit" : "Next");

        LinearLayout.LayoutParams nextParams = (LinearLayout.LayoutParams) nextButton.getLayoutParams();

        if (currentQuestion == 0) {
            prevButton.setVisibility(View.GONE);
            nextParams.width = LinearLayout.LayoutParams.WRAP_CONTENT;
            nextParams.gravity = Gravity.CENTER_HORIZONTAL;
            nextButton.setLayoutParams(nextParams);
        } else {
            prevButton.setVisibility(View.VISIBLE);
            nextParams.width = 0;
            nextParams.weight = 1;
            nextParams.gravity = Gravity.NO_GRAVITY;
            nextButton.setLayoutParams(nextParams);
        }
    }

    // Show final result dialog and save personality
    private void showResults() {
        int total = 0;
        for (int ans : answers) total += ans;

        String type, desc;

        if (total <= 20) {
            type = "Helper";
            desc = "You are kind and patient, you care for others!";
        } else if (total <= 30) {
            type = "Thinker";
            desc = "You are logical and calm, you solve problems thoughtfully!";
        } else if (total <= 40) {
            type = "Creator";
            desc = "You are imaginative and expressive, full of ideas!";
        } else {
            type = "Leader";
            desc = "You are confident and inspiring, you take charge naturally!";
        }

        Log.d("QuestionActivity", "Quiz finished for " + userName + ". Total score: " + total + ", Type: " + type);

        // Save user's personality
        SharedPreferences prefs = getSharedPreferences("PersonalityApp", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        String userKey = userName.toLowerCase().trim() + "_" + userAge.trim();
        editor.putString(userKey, type);
        editor.apply();

        // Show final dialog
        new AlertDialog.Builder(this)
                .setTitle("Your Personality: " + type)
                .setMessage(desc + "\n\nScore: " + total)
                .setPositiveButton("OK", (dialog, which) -> {
                    Log.d("QuestionActivity", "User confirmed results, returning to MainActivity");
                    Intent intent = new Intent(Question.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("Retake", (dialog, which) -> {
                    Log.d("QuestionActivity", "User chose to retake the quiz");
                    Intent intent = new Intent(Question.this, Question.class);
                    intent.putExtra("userName", userName);
                    intent.putExtra("userAge", userAge);
                    startActivity(intent);
                    finish();
                })
                .setCancelable(false)
                .show();
    }
}
