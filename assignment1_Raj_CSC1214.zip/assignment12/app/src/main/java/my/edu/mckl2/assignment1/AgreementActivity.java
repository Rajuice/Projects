package my.edu.mckl2.assignment1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.util.Log;

public class AgreementActivity extends AppCompatActivity {

    // UI references
    CheckBox cbAgree;
    Button btnNext;
    TextView tvSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agreement);

        // Initialize UI elements
        cbAgree = findViewById(R.id.cbAgree);
        btnNext = findViewById(R.id.btnNext);
        tvSummary = findViewById(R.id.tvSummary);

        // Get passed data from MainActivity
        String name = getIntent().getStringExtra("userName");
        String age = getIntent().getStringExtra("userAge");

        Log.d("AgreementActivity", "Agreement loaded for user: " + name + ", Age: " + age);

        // Display welcome message
        tvSummary.setText("Welcome " + name + "!");

        // Next button listener
        btnNext.setOnClickListener(v -> {
            if (!cbAgree.isChecked()) {
                Toast.makeText(this, "Please agree to continue", Toast.LENGTH_SHORT).show();
                Log.d("AgreementActivity", "User tried to continue without agreeing");
            } else {
                Log.d("AgreementActivity", "User agreed, moving to Instructions: " + name);
                Intent intent = new Intent(AgreementActivity.this, Instruction.class);
                intent.putExtra("userName", name);
                intent.putExtra("userAge", age);
                startActivity(intent);
            }
        });
    }
}
